DROP TABLE IF EXISTS sch_api_sgs_data.estado_civil CASCADE;
CREATE TABLE sch_api_sgs_data.estado_civil
(
  id serial NOT NULL, -- 
  etc_nome character(100)
  );
  
-- FIM ESTADO CIVIL

-- TABELA PROFISSOES
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar profissoes das pessoas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.profissoes CASCADE;
CREATE TABLE sch_api_sgs_data.profissoes
(
  id serial NOT NULL, -- 
  pfs_nome character(100)
  );
  
-- FIM profissoes

-- TABELA PESSOAS_FISICAS
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar da entidade pessoas fisicas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.pessoas_fisicas CASCADE;
CREATE TABLE sch_api_sgs_data.pessoas_fisicas
(
  id serial NOT NULL,
  psf_pss_id integer NOT NULL,
  psf_nome character(70),
  psf_sexo character(1),
  psf_data_nascimento date,
  psf_nome_mae character(70),
  psf_nome_pai character(70),
  psf_numero_cpf character(11),
  psf_numero_rg character(15),
  psf_renda numeric(10,2),
  psf_uf_rg character(2),
  psf_orgao_rg character(5),
  psf_portador_deficiencia character(1),
  psf_data_expedicao_rg date,
  psf_foto oid,
  psf_nivel_escolar integer,
  psf_profissao_id integer,
  psf_codigo_pais_rg integer,
  psf_estado_civil_id integer
  );
  
-- FIM PESSOAS FISICAS

-- TABELA PESSOAS_JURIDICAS
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar da entidade pessoas juridicas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.pessoas_juridicas CASCADE;
CREATE TABLE sch_api_sgs_data.pessoas_juridicas
(
  id serial NOT NULL,
  psj_pss_id integer NOT NULL,
  psj_razao_social character(100),
  psj_nome_fantasia character(50),
  psj_cgc character(18),
  psj_area_atuacao character(18),
  psj_faturamento numeric(15,2),
  psj_numero_inscricao_estadual character(20),
  psj_numero_inscricao_municipal character(20),
  psj_cei character(15),
  psj_percentual_iss numeric(10,2),
  psj_home_page character(30)
 );
  
-- FIM PESSOAS JURIDICAS

-- TABELA TIPOS_CONTATOS
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar tipos contatos das pessoas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.tipos_contatos CASCADE;
CREATE TABLE sch_api_sgs_data.tipos_contatos
(
  id serial NOT NULL,
  tct_nome character(100)
  );
  
-- FIM tipos_contatos

-- TABELA CONTATOS
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar contatos das pessoas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.contatos CASCADE;
CREATE TABLE sch_api_sgs_data.contatos
(
  id serial NOT NULL,
  ctt_tct_id integer,
  ctt_descricao character(100),
  ctt_obs text,
  ctt_pss_id integer
  );
  
-- FIM tipos_contatos

-- TABELA LOUGRADOUROS 
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar lougadouros
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.lougradouros CASCADE;
CREATE TABLE sch_api_sgs_data.lougradouros
(
  id serial NOT NULL,
  lgd_nome character(150),
  lgd_tlg_id integer,
  lgd_cep character(15),
  lgd_nome_abreviado character(50)
  );
  
-- FIM LOUGRADOUROS

-- TABELA BAIRROS 
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar bairros
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.bairros CASCADE;
CREATE TABLE sch_api_sgs_data.bairros
(
  id serial NOT NULL,
  brr_nome character(100)
  );
  
-- FIM bairros

-- TABELA CIDADES
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar cidades
-- 
-- 

DROP TABLE IF EXISTS sch_api_sgs_data.cidades CASCADE;
CREATE TABLE sch_api_sgs_data.cidades
(
  id serial NOT NULL,
  cdd_nome character(100)
  );
  
-- FIM cidades


-- TABELA UF
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar unidades federativas e siglas
-- 
-- 

DROP TABLE IF EXISTS sch_api_sgs_data.uf CASCADE;
CREATE TABLE sch_api_sgs_data.uf
(
  id serial NOT NULL,
  unf_nome character(100),
  unf_sigla character(2)
  );
  
-- FIM uf


-- TABELA ENDRECOS_PESSOA
-- By Carnegie
-- DATA CRIAÇÃO: 01/07/2014 
--
-- DESCRIÇÃO: 
-- Repositório destinado a armazenar enderecos de determinada pessoa
-- 
-- 

DROP TABLE IF EXISTS sch_api_sgs_data.enderecos_pessoa CASCADE;
CREATE TABLE sch_api_sgs_data.enderecos_pessoa
(
  id integer NOT NULL,
  epe_pss_id_pessoa integer NOT NULL,
  epe_corresp character varying(1),
  epe_complemento character varying(70),
  epe_tipo_endereco character varying(1),
  epe_numero numeric(10,2),
  epe_lgd_id integer,
  epe_brr_id integer,
  epe_cdd_id integer,
  epe_unf_id integer
  );
  
-- FIM enderecos_pessoa


--estado_civil

ALTER TABLE sch_api_sgs_data.estado_civil  ADD CONSTRAINT pk_estado_civil PRIMARY KEY(id)  USING INDEX TABLESPACE indx_tblsp_sgs;

--profissoes

ALTER TABLE sch_api_sgs_data.profissoes ADD CONSTRAINT pk_profissoes PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;


--PESSOAS FISICAS

ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT pk_pessoas_fisicas PRIMARY KEY (id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT fk_pessoas_fisicas FOREIGN KEY (psf_pss_id) REFERENCES sch_api_sgs_data.pessoas (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT fk_pessoas_fisicas_estado_civil FOREIGN KEY (psf_profissao_id) REFERENCES sch_api_sgs_data.estado_civil (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT fk_pessoas_fisicas_profissoes FOREIGN KEY (psf_profissao_id) REFERENCES sch_api_sgs_data.profissoes (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT uk_pessoas_fisicas_cpf UNIQUE (psf_numero_cpf);
CREATE INDEX fki_pessoas_fisicas ON sch_api_sgs_data.pessoas_fisicas USING btree (psf_pss_id);
CREATE INDEX idx_pessoas_fisicas_cpf ON sch_api_sgs_data.pessoas_fisicas USING btree (psf_numero_cpf COLLATE pg_catalog."default") TABLESPACE indx_tblsp_sgs;
CREATE INDEX idx_pessoas_fisicas_nome ON sch_api_sgs_data.pessoas_fisicas USING btree (psf_nome COLLATE pg_catalog."default") TABLESPACE indx_tblsp_sgs;


-- PESSOAS JURIDICAS

ALTER TABLE sch_api_sgs_system.pessoas_juridicas ADD CONSTRAINT pk_pessoas_juridicas PRIMARY KEY (id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.pessoas_juridicas ADD CONSTRAINT fk_pessoas_juridicas FOREIGN KEY (psj_pss_id) REFERENCES sch_api_sgs_data.pessoas (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
CREATE INDEX fki_pessoas_juridicas ON sch_api_sgs_data.pessoas_juridicas USING btree (psj_pss_id);
CREATE INDEX idx_pessoas_juridicas_nome ON sch_api_sgs_data.pessoas_juridicas USING btree (psj_razao_social COLLATE pg_catalog."default") TABLESPACE indx_tblsp_sgs;
CREATE INDEX idx_pessoas_juridicas_cgc ON sch_api_sgs_data.pessoas_juridicas USING btree (psj_cgc COLLATE pg_catalog."default") TABLESPACE indx_tblsp_sgs;


--tipos_contatos

ALTER TABLE sch_api_sgs_data.tipos_contatos ADD CONSTRAINT pk_tipos_contatos PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;

--contatos

ALTER TABLE sch_api_sgs_data.contatos ADD CONSTRAINT pk_contatos PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.contatos ADD CONSTRAINT fk_contatos FOREIGN KEY (ctt_tct_id) REFERENCES sch_api_sgs_data.tipos_contatos (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.contatos ADD CONSTRAINT fk_contatos_pessoa FOREIGN KEY (ctt_pss_id) REFERENCES sch_api_sgs_data.pessoas (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
CREATE INDEX fki_contatos_pessoa ON sch_api_sgs_data.contatos USING btree (ctt_pss_id);

-- lougradouros

ALTER TABLE sch_api_sgs_data.lougradouros ADD CONSTRAINT pk_logradouros PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;

--bairros

ALTER TABLE sch_api_sgs_data.bairros ADD CONSTRAINT pk_bairros PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;

--cidades

ALTER TABLE sch_api_sgs_data.cidades ADD CONSTRAINT pk_cidades PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;

--uf

ALTER TABLE sch_api_sgs_data.uf ADD CONSTRAINT pk_uf PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.uf ADD CONSTRAINT uk_uf_nome UNIQUE(unf_nome) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.uf ADD CONSTRAINT uk_uf_sigla UNIQUE(unf_sigla) USING INDEX TABLESPACE indx_tblsp_sgs;


--enderecos_pessoa

ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT pk_enderecos_pessoas PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT enderecos_pessoa_cidades FOREIGN KEY (epe_cdd_id) REFERENCES sch_api_sgs_data.cidades (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT fk_enderecos_logradouro FOREIGN KEY (epe_lgd_id) REFERENCES sch_api_sgs_data.lougradouros (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT fk_enderecos_pessoa_bairros FOREIGN KEY (epe_brr_id) REFERENCES sch_api_sgs_data.bairros (id) MATCH SIMPLE	ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT fk_enderecos_pessoa_uf FOREIGN KEY (epe_unf_id) REFERENCES sch_api_sgs_data.uf (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT fk_enderecos_pessoas FOREIGN KEY (epe_pss_id_pessoa) REFERENCES sch_api_sgs_data.pessoas (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;






