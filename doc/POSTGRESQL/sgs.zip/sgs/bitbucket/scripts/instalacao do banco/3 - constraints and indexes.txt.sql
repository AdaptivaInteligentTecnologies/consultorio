-- PESSOAS
ALTER TABLE sch_api_sgs_data.pessoas ADD CONSTRAINT pk_pessoas_id PRIMARY KEY(id) USING INDEX TABLESPACE data_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.pessoas ALTER COLUMN id SET NOT NULL;
ALTER TABLE sch_api_sgs_data.pessoas ALTER COLUMN id SET NOT NULL;
ALTER TABLE sch_api_sgs_data.pessoas ADD CONSTRAINT 	chk_pss_tipo	CHECK (upper(pss_tipo) in ('F','J')) NO INHERIT;
ALTER TABLE sch_api_sgs_data.pessoas ADD CONSTRAINT 	chk_pss_ativo	CHECK (upper(pss_ativo) in ('S','N')) NO INHERIT;
CREATE INDEX indx_pss_tipo_pessoa on sch_api_sgs_data.pessoas(pss_tipo) TABLESPACE indx_tblsp_sgs;

-- UNIDADES
ALTER TABLE sch_api_sgs_system.unidades ALTER COLUMN	id 						SET NOT NULL;
ALTER TABLE sch_api_sgs_system.unidades ALTER COLUMN	und_nome 				SET NOT NULL;
ALTER TABLE sch_api_sgs_system.unidades ADD CONSTRAINT	pk_unidades_id 			PRIMARY KEY(id) 	USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.unidades ADD CONSTRAINT	uq_unidades_tuf_nome 	UNIQUE (und_nome) 	USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.unidades ADD CONSTRAINT	fk_unidades_und_pss_id	FOREIGN KEY (und_pss_id) REFERENCES sch_api_sgs_system.pessoas (id);
CREATE INDEX idx_sch_api_sgs_unidades_und_nome on sch_api_sgs_system.unidades(und_nome) TABLESPACE indx_tblsp_sgs;
--//ALTER SEQUENCE sch_api_sgs_system.unidades_id_seq RESTART WITH 1;


-- USUARIOS
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	id 								SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	usu_senha 						SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	usu_nome 						SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	usu_login 						SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	usu_ativo 						SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	usu_ativo 						SET DEFAULT 'S';
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	usu_expirar_senha				SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	usu_expirar_senha				SET DEFAULT 'N';
ALTER TABLE sch_api_sgs_system.usuarios ALTER COLUMN	usu_dt_criacao					SET DEFAULT 'NOW';
ALTER TABLE sch_api_sgs_system.usuarios ADD CONSTRAINT	pk_usuarios_id 					PRIMARY KEY(id) 	USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.usuarios ADD CONSTRAINT	uq_usuarios_usu_nome_usu_senha 	UNIQUE (usu_nome,usu_senha) 	USING INDEX TABLESPACE indx_tblsp_sgs;
CREATE INDEX idx_sch_api_sgs_usuarios_usu_nome on sch_api_sgs_system.usuarios(usu_nome) TABLESPACE indx_tblsp_sgs;
CREATE INDEX idx_sch_api_sgs_usuarios_usu_nome_usu_senha on sch_api_sgs_system.usuarios(usu_nome,usu_senha) TABLESPACE indx_tblsp_sgs;
--//ALTER SEQUENCE sch_api_sgs_system.usuarios_id_seq RESTART WITH 1;
-- FIM USUARIOS


-- UNIDADES_TEM_USUARIOS

ALTER TABLE sch_api_sgs_system.unidades_tem_usuarios ALTER COLUMN	id 													SET NOT NULL;
ALTER TABLE sch_api_sgs_system.unidades_tem_usuarios ALTER COLUMN	utu_usuarios_id										SET NOT NULL;
ALTER TABLE sch_api_sgs_system.unidades_tem_usuarios ALTER COLUMN	utu_unidades_id										SET NOT NULL;
ALTER TABLE sch_api_sgs_system.unidades_tem_usuarios ADD CONSTRAINT	pk_unidades_tem_usuarios_id 						PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.unidades_tem_usuarios ADD CONSTRAINT	uq_unidades_tem_usuarios_utu_usuarios_utu_unidades 	UNIQUE (utu_usuarios_id,utu_unidades_id) 	USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.unidades_tem_usuarios ADD CONSTRAINT	fk_unidades_tem_usuarios_utu_usuarios_id			FOREIGN KEY (utu_usuarios_id) REFERENCES sch_api_sgs_system.usuarios (id);
ALTER TABLE sch_api_sgs_system.unidades_tem_usuarios ADD CONSTRAINT	fk_unidades_tem_usuarios_utu_unidades_id 			FOREIGN KEY (utu_unidades_id) REFERENCES sch_api_sgs_system.unidades (id);
-- FIM UNIDADES_TEM_USUARIOS


-- PERFIS
ALTER TABLE sch_api_sgs_system.perfis ALTER COLUMN	id 						SET NOT NULL;
ALTER TABLE sch_api_sgs_system.perfis ALTER COLUMN	prl_ativo 				SET NOT NULL;
ALTER TABLE sch_api_sgs_system.perfis ALTER COLUMN	prl_ativo 				SET DEFAULT 'S';
ALTER TABLE sch_api_sgs_system.perfis ALTER COLUMN	prl_dt_criacao			SET DEFAULT now();
ALTER TABLE sch_api_sgs_system.perfis ADD CONSTRAINT	pk_perfis_id 		PRIMARY KEY(id) 	USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.perfis ADD CONSTRAINT	uq_perfis_prl_nome	UNIQUE (prl_nome) 	USING INDEX TABLESPACE indx_tblsp_sgs;
CREATE INDEX idx_sch_api_sgs_perfis_prl_nome on sch_api_sgs_system.perfis(prl_nome) TABLESPACE indx_tblsp_sgs;
--//ALTER SEQUENCE sch_api_sgs_system.perfis_id_seq RESTART WITH 1;
-- FIM PERFIS


-- USUARIOS_TEM_PERFIS
ALTER TABLE sch_api_sgs_system.usuarios_tem_perfis ALTER COLUMN	id 																	SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios_tem_perfis ALTER COLUMN	usu_prl_usuarios_id													SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios_tem_perfis ALTER COLUMN	usu_prl_perfis_id													SET NOT NULL;
ALTER TABLE sch_api_sgs_system.usuarios_tem_perfis ADD CONSTRAINT	pk_usuarios_tem_perfis_id										PRIMARY KEY(id) 		USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.usuarios_tem_perfis ADD CONSTRAINT	uq_usuarios_tem_perfis_usu_prl_perfis_id_usu_prl_usuarios_id	UNIQUE (usu_prl_usuarios_id,usu_prl_perfis_id)  USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.usuarios_tem_perfis ADD CONSTRAINT	fk_usuarios_tem_perfis_usu_prl_usuarios_id 						FOREIGN KEY (usu_prl_usuarios_id) REFERENCES sch_api_sgs_system.usuarios (id);
ALTER TABLE sch_api_sgs_system.usuarios_tem_perfis ADD CONSTRAINT	fk_usuarios_tem_perfis_usu_prl_perfis_id 						FOREIGN KEY (usu_prl_perfis_id) REFERENCES sch_api_sgs_system.perfis (id);
CREATE INDEX idx_sch_api_sgs_usuarios_tem_perfis_usu_prl_usuario_id_usu_prl_perfis_id on sch_api_sgs_system.usuarios_tem_perfis(usu_prl_usuarios_id,usu_prl_perfis_id) TABLESPACE indx_tblsp_sgs;
--//ALTER SEQUENCE sch_api_sgs_system.usuarios_tem_perfis_id_seq RESTART WITH 1;
-- FIM USUARIOS_TEM_PERFIS


-- MODULOS
ALTER TABLE sch_api_sgs_system.modulos ALTER COLUMN	id 							SET NOT NULL;
ALTER TABLE sch_api_sgs_system.modulos ALTER COLUMN	mod_imagem 					SET DEFAULT 'app/images/ico/default.png';
ALTER TABLE sch_api_sgs_system.modulos ADD CONSTRAINT	pk_modulos_id			PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.modulos ADD CONSTRAINT	uq_modulos_mod_nome		UNIQUE (mod_nome)			USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.modulos ADD CONSTRAINT fk_modulos_mod_modulos_id FOREIGN KEY (mod_modulos_id) REFERENCES sch_api_sgs_system.modulos (id);
CREATE INDEX idx_sch_api_sgs_modulos_mod_nome on sch_api_sgs_system.modulos(mod_nome) 		TABLESPACE indx_tblsp_sgs;
CREATE INDEX idx_sch_api_sgs_modulos_mod_modulos_id on sch_api_sgs_system.modulos(mod_modulos_id) 	TABLESPACE indx_tblsp_sgs;


-- PERFIS_TEM_MODULOS
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ALTER COLUMN		id 											SET NOT NULL;
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ALTER COLUMN		prl_mod_modulos_id							SET NOT NULL;
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ALTER COLUMN		prl_mod_perfis_id							SET NOT NULL;
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ALTER COLUMN		prl_mod_excluir 							SET DEFAULT 'N';
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ALTER COLUMN		prl_mod_incluir 							SET DEFAULT 'N';
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ALTER COLUMN		prl_mod_editar 								SET DEFAULT 'N';
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ADD CONSTRAINT 	chk_perfis_tem_modulos_prl_mod_incluir 		CHECK (upper(prl_mod_incluir) in ('S','N')) NO INHERIT;
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ADD CONSTRAINT 	chk_perfis_tem_modulos_prl_mod_excluir 		CHECK (upper(prl_mod_excluir) in ('S','N')) NO INHERIT;
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ADD CONSTRAINT 	chk_perfis_tem_modulos_prl_mod_editar 		CHECK (upper(prl_mod_editar) in ('S','N')) NO INHERIT;
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ADD CONSTRAINT	pk_perfis_tem_modulos_id					PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ADD CONSTRAINT 	fk_perfis_tem_modulos_prl_mod_modulos_id 	FOREIGN KEY (prl_mod_modulos_id) REFERENCES sch_api_sgs_system.modulos (id);
ALTER TABLE sch_api_sgs_system.perfis_tem_modulos ADD CONSTRAINT 	fk_perfis_tem_modulos_prl_mod_perfis_id 	FOREIGN KEY (prl_mod_perfis_id) REFERENCES sch_api_sgs_system.perfis (id);
CREATE INDEX idx_sch_api_sgs_peris_tem_modulos_modulos_id_perfis_id on sch_api_sgs_system.perfis_tem_modulos(prl_mod_modulos_id,prl_mod_perfis_id) TABLESPACE indx_tblsp_sgs;

--estado_civil

ALTER TABLE sch_api_sgs_data.estado_civil  ADD CONSTRAINT pk_estado_civil PRIMARY KEY(id)  USING INDEX TABLESPACE indx_tblsp_sgs;

--profissoes

ALTER TABLE sch_api_sgs_data.profissoes ADD CONSTRAINT pk_profissoes PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;


--PESSOAS FISICAS

ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT pk_pessoas_fisicas PRIMARY KEY (id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT fk_pessoas_fisicas FOREIGN KEY (psf_pss_id) REFERENCES sch_api_sgs_data.pessoas (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT fk_pessoas_fisicas_estado_civil FOREIGN KEY (psf_profissao_id) REFERENCES sch_api_sgs_data.estado_civil (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT fk_pessoas_fisicas_profissoes FOREIGN KEY (psf_profissao_id) REFERENCES sch_api_sgs_data.profissoes (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_system.pessoas_fisicas ADD CONSTRAINT uk_pessoas_fisicas_cpf UNIQUE (psf_numero_cpf);
CREATE INDEX fki_pessoas_fisicas ON sch_api_sgs_data.pessoas_fisicas USING btree (psf_pss_id);
CREATE INDEX idx_pessoas_fisicas_cpf ON sch_api_sgs_data.pessoas_fisicas USING btree (psf_numero_cpf COLLATE pg_catalog."default") TABLESPACE indx_tblsp_sgs;
CREATE INDEX idx_pessoas_fisicas_nome ON sch_api_sgs_data.pessoas_fisicas USING btree (psf_nome COLLATE pg_catalog."default") TABLESPACE indx_tblsp_sgs;


-- PESSOAS JURIDICAS

ALTER TABLE sch_api_sgs_system.pessoas_juridicas ADD CONSTRAINT pk_pessoas_juridicas PRIMARY KEY (id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_system.pessoas_juridicas ADD CONSTRAINT fk_pessoas_juridicas FOREIGN KEY (psj_pss_id) REFERENCES sch_api_sgs_data.pessoas (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
CREATE INDEX fki_pessoas_juridicas ON sch_api_sgs_data.pessoas_juridicas USING btree (psj_pss_id);
CREATE INDEX idx_pessoas_juridicas_nome ON sch_api_sgs_data.pessoas_juridicas USING btree (psj_razao_social COLLATE pg_catalog."default") TABLESPACE indx_tblsp_sgs;
CREATE INDEX idx_pessoas_juridicas_cgc ON sch_api_sgs_data.pessoas_juridicas USING btree (psj_cgc COLLATE pg_catalog."default") TABLESPACE indx_tblsp_sgs;


--tipos_contatos

ALTER TABLE sch_api_sgs_data.tipos_contatos ADD CONSTRAINT pk_tipos_contatos PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;

--contatos

ALTER TABLE sch_api_sgs_data.contatos ADD CONSTRAINT pk_contatos PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.contatos ADD CONSTRAINT fk_contatos FOREIGN KEY (ctt_tct_id) REFERENCES sch_api_sgs_data.tipos_contatos (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.contatos ADD CONSTRAINT fk_contatos_pessoa FOREIGN KEY (ctt_pss_id) REFERENCES sch_api_sgs_data.pessoas (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
CREATE INDEX fki_contatos_pessoa ON sch_api_sgs_data.contatos USING btree (ctt_pss_id);

-- lougradouros

ALTER TABLE sch_api_sgs_data.lougradouros ADD CONSTRAINT pk_logradouros PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;

--bairros

ALTER TABLE sch_api_sgs_data.bairros ADD CONSTRAINT pk_bairros PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;

--cidades

ALTER TABLE sch_api_sgs_data.cidades ADD CONSTRAINT pk_cidades PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;

--uf

ALTER TABLE sch_api_sgs_data.uf ADD CONSTRAINT pk_uf PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.uf ADD CONSTRAINT uk_uf_nome UNIQUE(unf_nome) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.uf ADD CONSTRAINT uk_uf_sigla UNIQUE(unf_sigla) USING INDEX TABLESPACE indx_tblsp_sgs;


--enderecos_pessoa

ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT pk_enderecos_pessoas PRIMARY KEY(id) USING INDEX TABLESPACE indx_tblsp_sgs;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT enderecos_pessoa_cidades FOREIGN KEY (epe_cdd_id) REFERENCES sch_api_sgs_data.cidades (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT fk_enderecos_logradouro FOREIGN KEY (epe_lgd_id) REFERENCES sch_api_sgs_data.lougradouros (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT fk_enderecos_pessoa_bairros FOREIGN KEY (epe_brr_id) REFERENCES sch_api_sgs_data.bairros (id) MATCH SIMPLE	ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT fk_enderecos_pessoa_uf FOREIGN KEY (epe_unf_id) REFERENCES sch_api_sgs_data.uf (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE sch_api_sgs_data.enderecos_pessoa ADD CONSTRAINT fk_enderecos_pessoas FOREIGN KEY (epe_pss_id_pessoa) REFERENCES sch_api_sgs_data.pessoas (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;