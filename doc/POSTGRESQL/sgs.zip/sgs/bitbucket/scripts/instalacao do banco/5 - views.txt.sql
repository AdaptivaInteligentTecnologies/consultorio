-- LOGIN USU�RIO
DROP VIEW IF EXISTS sch_api_sgs_system.programas_do_usuario
CREATE VIEW sch_api_sgs_system.programas_do_usuario AS
SELECT
	usu.id				AS usu_id,
	mod.id 				AS mod_id,
	mod.mod_modulos_id 	AS mod_modulo_pai,
	und.id				AS und_id,
	und.und_nome		AS unidade,
	mod.mod_nome 		AS modulo,
	mod.mod_controller 	AS controller,
	mod.mod_imagem 		AS IMAGEM,
	prl_mod_incluir 	AS INCLUIR,
	prl_mod_excluir 	AS EXCLUIR,
	prl_mod_editar 		AS EDITAR
FROM
		sch_api_sgs_system.modulos mod
INNER JOIN 	sch_api_sgs_system.perfis_tem_modulos prl_mod on prl_mod.prl_mod_modulos_id = mod.id
INNER JOIN 	sch_api_sgs_system.perfis prl on prl_mod.prl_mod_perfis_id = prl.id
INNER JOIN 	sch_api_sgs_system.usuarios_tem_perfis usu_prl on usu_prl.usu_prl_perfis_id = prl.id
INNER JOIN 	sch_api_sgs_system.usuarios usu on usu_prl.usu_prl_usuarios_id = usu.id
INNER JOIN	sch_api_sgs_system.unidades_tem_usuarios utu on utu.utu_usuarios_id = usu.id
INNER JOIN 	sch_api_sgs_system.unidades und on und.id = utu.utu_unidades_id
WHERE
	prl.prl_ativo = 'S';
