-- 
--
-- DATA DE CRIA��O: 30/06/2014
-- DATA DE ALTERA��O: 30/06/2014
-- REPONS�VEL:
-- OBSERVA��O: 
--

DROP TABLE IF EXISTS sch_api_sgs_data.pessoas;
CREATE TABLE sch_api_sgs_data.pessoas
(
	id	serial,
	pss_tipo char(1),
	pss_ativo char(1)
);


-- TABELA UNIDADES
-- Criador Carnegie
-- DATA CRIA��O: 23/06/2014 
-- ALTERADO POR: CARNEGIE DATA DE MODIFICA��O: 13/06/2014
-- Reposit�rio destinado a armazenar dados das unidades setoriais pertencentes a cada ator do sistema
--
DROP TABLE IF EXISTS sch_api_sgs_system.unidades CASCADE;
CREATE TABLE sch_api_sgs_system.unidades
(
	id serial,
	und_nome character varying(35),
	und_pss_id integer

);



-- TABELA USUARIOS
-- By Carnegie
-- DATA CRIA��O: 13/06/2014 
-- ALTERADO POR: CARNEGIE 
-- Reposit�rio destinado a armazenar dados dos usu�rios que ter�o acesso ao sistema
-- DATA DE MODIFICA��O:13/06/2014
-- Obs da altera��o: Campo USU_FOTO ADICIONADO. para inserir dato em tablela usar: 
-- INSERT INTO imagem (...,usu_foto) VALUES (...,lo_import('c:/figuras/figura.jpg'));
-- para extrair: SELECT lo_export('nomedafigura.jpg','c:/temp/figura1.jpg') FROM imagem WHERE campo = condi��o;

DROP TABLE IF EXISTS sch_api_sgs_system.usuarios CASCADE;
CREATE TABLE sch_api_sgs_system.usuarios -- campos sufixados por: usu_
(
	id 						serial,
	usu_nome				character varying(35),
	usu_login 				character varying(25),
	usu_senha 				character varying(32),
	usu_email 				character varying(50),
	usu_ativo 				character(1),
	usu_foto				oid,
	usu_expirar_senha 		character(1),
	usu_dt_expirar_senha	timestamp,
	usu_dt_criacao			timestamp
);
-- FIM USU�RIOS



-- TABELA UNIDADES_TEM_USUARIOS
-- By Carnegie
-- DATA CRIA��O: 23/06/2014 
-- ALTERADO POR: CARNEGIE DATA DE MODIFICA��O:13/06/2014
-- Reposit�rio destinado a armazenar dados das unidades setoriais pertencentes a cada ator do sistema
--
DROP TABLE IF EXISTS sch_api_sgs_system.unidades_tem_usuarios CASCADE;
CREATE TABLE sch_api_sgs_system.unidades_tem_usuarios
(
	id serial,
	utu_usuarios_id integer,
	utu_unidades_id integer
);
-- FIM USUARIOS_TEM_UNIDADES



-- TABELA PERFIS
-- By Carnegie
-- DATA CRIA��O: 13/06/2014 DATA DE MODIFICA��O:13/06/2014
-- Reposit�rio destinado a armazenar dados dos perfis de usu�rios que ter�o acesso ao sistema
--
DROP TABLE IF EXISTS sch_api_sgs_system.perfis CASCADE;
CREATE TABLE sch_api_sgs_system.perfis -- campos sufixados por: prl_
(
	id 			serial,
	prl_nome  		character varying(25),
	prl_ativo 		character(1),
	prl_dt_criacao		timestamp
);
-- FIM PERFIS



-- TABELA USUARIOS_TEM_PERFIS
-- By Carnegie
-- DATA CRIA��O: 13/06/2014 DATA DE MODIFICA��O:13/06/2014
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar os relacionamentos entre
-- as rela��es perfis e usu�rios atrav�s de: perfis(id) e usuarios(id):
-- usuarios(id) e perfis(id)
DROP TABLE IF EXISTS sch_api_sgs_system.usuarios_tem_perfis CASCADE;
CREATE TABLE sch_api_sgs_system.usuarios_tem_perfis -- sufixado por usu_prl_
(
	id 			serial,
	usu_prl_usuarios_id	integer,
	usu_prl_perfis_id	integer
);
-- FIM PERFIS_TEM_USUARIOS


-- TABELA MODULOS
-- By Carnegie
-- DATA CRIA��O: 14/06/2014 
-- ALTERADO POR: CARNEGIE DATA DE MODIFICA��O: 18/06/2014
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar os m�dulos que ser�o usados pelos usu�rios
-- as rela��es perfis e usu�rios atrav�s de: perfis(id) e usuarios(id):
-- usuarios(id) e perfis(id)
DROP TABLE IF EXISTS sch_api_sgs_system.modulos CASCADE;
CREATE TABLE sch_api_sgs_system.modulos -- campos sufixados por: mod_
(
	id 			serial,
	mod_modulos_id		integer,
	mod_nome		character varying(35),
	mod_descricao		character varying(100),
	mod_controller		character varying(50),
	mod_imagem		character varying(255)
);
-- FIM MODULOS


-- TABELA PERFIS_TEM_MODULOS
-- By Carnegie
-- DATA CRIA��O: 14/06/2014 DATA DE MODIFICA��O: 14/06/2014
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar os m�dulos que compor�o o perfil de usu�rio
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_system.perfis_tem_modulos CASCADE;
CREATE TABLE sch_api_sgs_system.perfis_tem_modulos -- campos sufixados por: prl_mod_
(
	id 						serial,
	prl_mod_modulos_id		integer,
	prl_mod_perfis_id		integer,
	prl_mod_incluir			character(1),
	prl_mod_excluir			character(1),
	prl_mod_editar			character(1)
);
-- FIM PERFIS_TEM_MODULOS

DROP TABLE IF EXISTS sch_api_sgs_data.estado_civil CASCADE;
CREATE TABLE sch_api_sgs_data.estado_civil
(
  id serial NOT NULL, -- 
  etc_nome character(100)
  );
  
-- FIM ESTADO CIVIL

-- TABELA PROFISSOES
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar profissoes das pessoas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.profissoes CASCADE;
CREATE TABLE sch_api_sgs_data.profissoes
(
  id serial NOT NULL, -- 
  pfs_nome character(100)
  );
  
-- FIM profissoes

-- TABELA PESSOAS_FISICAS
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar da entidade pessoas fisicas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.pessoas_fisicas CASCADE;
CREATE TABLE sch_api_sgs_data.pessoas_fisicas
(
  id serial NOT NULL,
  psf_pss_id integer NOT NULL,
  psf_nome character(70),
  psf_sexo character(1),
  psf_data_nascimento date,
  psf_nome_mae character(70),
  psf_nome_pai character(70),
  psf_numero_cpf character(11),
  psf_numero_rg character(15),
  psf_renda numeric(10,2),
  psf_uf_rg character(2),
  psf_orgao_rg character(5),
  psf_portador_deficiencia character(1),
  psf_data_expedicao_rg date,
  psf_foto oid,
  psf_nivel_escolar integer,
  psf_profissao_id integer,
  psf_codigo_pais_rg integer,
  psf_estado_civil_id integer
  );
  
-- FIM PESSOAS FISICAS

-- TABELA PESSOAS_JURIDICAS
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar da entidade pessoas juridicas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.pessoas_juridicas CASCADE;
CREATE TABLE sch_api_sgs_data.pessoas_juridicas
(
  id serial NOT NULL,
  psj_pss_id integer NOT NULL,
  psj_razao_social character(100),
  psj_nome_fantasia character(50),
  psj_cgc character(18),
  psj_area_atuacao character(18),
  psj_faturamento numeric(15,2),
  psj_numero_inscricao_estadual character(20),
  psj_numero_inscricao_municipal character(20),
  psj_cei character(15),
  psj_percentual_iss numeric(10,2),
  psj_home_page character(30)
 );
  
-- FIM PESSOAS JURIDICAS

-- TABELA TIPOS_CONTATOS
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar tipos contatos das pessoas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.tipos_contatos CASCADE;
CREATE TABLE sch_api_sgs_data.tipos_contatos
(
  id serial NOT NULL,
  tct_nome character(100)
  );
  
-- FIM tipos_contatos

-- TABELA CONTATOS
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar contatos das pessoas
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.contatos CASCADE;
CREATE TABLE sch_api_sgs_data.contatos
(
  id serial NOT NULL,
  ctt_tct_id integer,
  ctt_descricao character(100),
  ctt_obs text,
  ctt_pss_id integer
  );
  
-- FIM tipos_contatos

-- TABELA LOUGRADOUROS 
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar lougadouros
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.lougradouros CASCADE;
CREATE TABLE sch_api_sgs_data.lougradouros
(
  id serial NOT NULL,
  lgd_nome character(150),
  lgd_tlg_id integer,
  lgd_cep character(15),
  lgd_nome_abreviado character(50)
  );
  
-- FIM LOUGRADOUROS

-- TABELA BAIRROS 
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar bairros
-- 
-- 
DROP TABLE IF EXISTS sch_api_sgs_data.bairros CASCADE;
CREATE TABLE sch_api_sgs_data.bairros
(
  id serial NOT NULL,
  brr_nome character(100)
  );
  
-- FIM bairros

-- TABELA CIDADES
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar cidades
-- 
-- 

DROP TABLE IF EXISTS sch_api_sgs_data.cidades CASCADE;
CREATE TABLE sch_api_sgs_data.cidades
(
  id serial NOT NULL,
  cdd_nome character(100)
  );
  
-- FIM cidades


-- TABELA UF
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar unidades federativas e siglas
-- 
-- 

DROP TABLE IF EXISTS sch_api_sgs_data.uf CASCADE;
CREATE TABLE sch_api_sgs_data.uf
(
  id serial NOT NULL,
  unf_nome character(100),
  unf_sigla character(2)
  );
  
-- FIM uf


-- TABELA ENDRECOS_PESSOA
-- By Carnegie
-- DATA CRIA��O: 01/07/2014 
--
-- DESCRI��O: 
-- Reposit�rio destinado a armazenar enderecos de determinada pessoa
-- 
-- 

DROP TABLE IF EXISTS sch_api_sgs_data.enderecos_pessoa CASCADE;
CREATE TABLE sch_api_sgs_data.enderecos_pessoa
(
  id integer NOT NULL,
  epe_pss_id_pessoa integer NOT NULL,
  epe_corresp character varying(1),
  epe_complemento character varying(70),
  epe_tipo_endereco character varying(1),
  epe_numero numeric(10,2),
  epe_lgd_id integer,
  epe_brr_id integer,
  epe_cdd_id integer,
  epe_unf_id integer
  );
  
-- FIM enderecos_pessoa







