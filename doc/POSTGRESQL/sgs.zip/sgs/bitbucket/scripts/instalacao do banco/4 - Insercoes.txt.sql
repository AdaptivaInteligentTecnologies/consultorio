-- UNIDADES
INSERT INTO sch_api_sgs_system.unidades(id,und_nome) values(1,'Padr�o');
-- FIM UNIDADES


-- USUARIOS
INSERT INTO sch_api_sgs_system.usuarios(id,usu_nome,usu_login,usu_senha,usu_email) VALUES(1,'Administrador','admin',md5('admin'),'admin@admin');


-- UNIDADES_TEM_USUARIOS
INSERT INTO sch_api_sgs_system.unidades_tem_usuarios(id,utu_usuarios_id,utu_unidades_id) VALUES(1,1,1);


-- PERFIS
INSERT INTO sch_api_sgs_system.perfis(id,prl_nome) values(1,'Administrador');


-- USUARIOS_TEM_PERFIS
INSERT INTO sch_api_sgs_system.usuarios_tem_perfis(id,usu_prl_usuarios_id,usu_prl_perfis_id) VALUES(1,1,1);


-- MODULOS
INSERT INTO sch_api_sgs_system.modulos(id,mod_nome,mod_imagem) values (1,'Configura��es de sistema','app/images/ico/configuracoessistema.png');
INSERT INTO sch_api_sgs_system.modulos(id,mod_modulos_id, mod_nome,mod_controller) values (2,1,'Par�metros','SystemParametrosController');
INSERT INTO sch_api_sgs_system.modulos(id,mod_modulos_id, mod_nome,mod_controller,mod_imagem) values (3,1,'Usu�rios','SystemCadUsuariosController','app/images/ico/usuarios.png');
INSERT INTO sch_api_sgs_system.modulos(id,mod_modulos_id, mod_nome,mod_controller) values (4,1,'Perfis','SystemCadPerfisController');


-- PERFIS_TEM_MODULOS
INSERT INTO sch_api_sgs_system.perfis_tem_modulos(id,prl_mod_modulos_id,prl_mod_perfis_id,prl_mod_incluir,prl_mod_excluir,prl_mod_editar) VALUES(1,1,1,'S','S','S');
INSERT INTO sch_api_sgs_system.perfis_tem_modulos(id,prl_mod_modulos_id,prl_mod_perfis_id,prl_mod_incluir,prl_mod_excluir,prl_mod_editar) VALUES(2,2,1,'S','S','S');
INSERT INTO sch_api_sgs_system.perfis_tem_modulos(id,prl_mod_modulos_id,prl_mod_perfis_id,prl_mod_incluir,prl_mod_excluir,prl_mod_editar) VALUES(3,3,1,'S','S','S');
INSERT INTO sch_api_sgs_system.perfis_tem_modulos(id,prl_mod_modulos_id,prl_mod_perfis_id,prl_mod_incluir,prl_mod_excluir,prl_mod_editar) VALUES(4,4,1,'S','S','S');
