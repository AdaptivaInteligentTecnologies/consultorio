<?php 
class ConfiguracaoSistemaController extends TPage
{
    public function __construct()
    {
        parent::__construct();
        parent::add('Configura��es do sistema');
    }
}