<?php
class Bancos extends TRecord
{
    const TABLENAME = 'sch_api_sgs_data.bancos';
    const PRIMARYKEY= 'id';
    //const IDPOLICY =  'max'; // {max, serial}
    const IDPOLICY =  'serial'; // {max, serial}
    
    	
}