
### A jump-start for jQuery plugins development

First take for a pretty jquery timeline.

## License

[MIT License](http://zenorocha.mit-license.org/) © Yehia A.Salam
